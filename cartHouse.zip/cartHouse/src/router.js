import Vue from "vue";
import Router from "vue-router";
import store from "./store";

import MainLayout from "@/layout/MainLayout";
import ProductDetails from "@/views/ProductDetails";
import Products from "@/views/Products";
// import EmptyLayout from "@/layout/EmptyLayout";
const originalPush = Router.prototype.push;
if (process.env.NODE_ENV !== "development")
  Router.prototype.push = function push(location) {
    return originalPush.call(this, location).catch(error => error);
  };
Vue.use(Router);


const router = new Router({
  mode: "history",
  base: process.env.BASE_URL,
  routes: [
    {
      path: "/",
      name: null,
      component: MainLayout,
      children: [
        {
          path:"/products",
          component: Products,
          name: "product-details",
        },
      {
        path:"/product-details/:productId",
        component: ProductDetails,
        name: "product-details",
      },]
    }
  ]
});

router.beforeEach((to, from, next) => {
  if (!store.getters["auth/apiURL"]) {
    store.commit("auth/intitializeAPI");
  }
  next();
});

export default router;
