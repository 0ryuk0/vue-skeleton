import Vue from "vue";

export default {
  namespaced: true,
  state: {
    apiURL: null
  },
  getters: {
    apiURL(state) {
      return state.apiURL;
    }
  },
  mutations: {
    intitializeAPI(state) {
      if (process.env.NODE_ENV === "production") {
        Vue.set(
          state,
          "apiURL",
          location.origin + process.env.VUE_APP_API_SLUG
        );
      } else {
        Vue.set(
          state,
          "apiURL",
          process.env.VUE_APP_API_BASE_URL + process.env.VUE_APP_API_SLUG
        );
      }
    }
  }
};
