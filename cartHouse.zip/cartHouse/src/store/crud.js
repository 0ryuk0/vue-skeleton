/* eslint-disable no-prototype-builtins */
import Vue from "vue";
import queryString from "qs";
import { $request } from "@/lib";
let qsOptions = { arrayFormat: "comma", skipNulls: true };

export default {
  namespaced: true,
  state: {
    list: {}
  },
  getters: {
    list(state) {
      return component => state.list[component] || {};
    }
  },
  mutations: {
    makeList(state, item) {
      Vue.set(state.list, item.component, item.data);
    },
    pushToList(state, item) {
      let component = item.key.as || item.key.component;
      Vue.set(state.list[component], "next", item.data.next);
      Vue.set(state.list[component], "previous", item.data.previous);
      item.data.results.map(d => {
        state.list[component].results.push(d);
      });
    },
  },
  actions: {
    get({ commit, rootState }, item) {
      console.log(rootState.config, rootState.config[item.component], item);
      const component = rootState.config[item.component];
      const pushToList = item.hasOwnProperty("pushToList");
      const id = item.id;
      let params = Object.assign(
        {},
        { apikey: process.env.VUE_APP_API_KEY },
        item.filters
      );
      return $request({
        method: "GET",
        url:
          component.api +
          (id ? id + "/" : "") +
          "?" +
          queryString.stringify(params, qsOptions),
        canceller: item.canceller
      })
        .then(data => {
          if (!pushToList)
            commit("makeList", {
              component: item.as || item.component,
              data: data
            });
          return { status: true, data: data };
        })
        .catch(errors => {
          return { status: false, errors: errors };
        });
    },
    getMore({ commit, state }, item) {
      let list = state.list[item.as || item.component];
      const pushToList = item.hasOwnProperty("pushToList");
      return $request({
        method: "GET",
        fullPath: true,
        url: item.next || (list.link ? list.link.next : list.next),
        canceller: item.canceller
      })
        .then(data => {
          if (!pushToList)
            commit("pushToList", {
              key: item,
              data: data
            });
          return { status: true, data: data };
        })
        .catch(errors => {
          return { status: false, errors: errors };
        });
    },
    getOne({ rootState }, item) {
      const component = rootState.config[item.component];
      const id = item.id || (item.model && item.model.unique_id) || null;
      return $request({
        method: "GET",
        url:
          component.api +
          "/" +
          (id ? id + "/" : "") +
          "?" +
          queryString.stringify(item.filters || {}, qsOptions)
      })
        .then(data => {
          return { status: true, data: data };
        })
        .catch(() => {
          return { status: false };
        });
    }
  }
};
