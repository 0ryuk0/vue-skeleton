export default {
  namespaced: true,
  state: {
    "product-list": {
      api: "products",
      defaultPageSize: 10
    }
  },
  getters: {
    get(state) {
      return state;
    },
    getComponent(state) {
      return component => state[component];
    }
  }
};
