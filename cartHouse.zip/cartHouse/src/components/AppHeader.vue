<template>
  <div class="header-wrapper">
    <div class="logo">Test Cart</div>
    <label class="search-box"><input type="text" placeholder="Search..." @keyup="$emit('search', query)" v-model="query"><button></button></label>
  </div>
</template>

<script>
export default {
  name: 'search-header',
  mounted(){
  },
  data(){
    return {
      query: ""
    }
  },
  methods:{
    
  }
}

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  .header-wrapper{
    display: flex;
    justify-content: space-between;
    padding: 1rem;
    border-bottom: 1px solid #efefef;
  }
  .logo{
      font-size: 1.8rem;
      color: #f13333;
      margin-right: 3rem;
      font-weight: 500;
  }
  .search-box{
    border: 0.1rem solid #efefef;
    padding: 0 1rem;
    border-radius: 0.3rem;
  }
  .search-box input{
    border: none;
    font-size: 1rem;
    min-width: 20rem;
    outline: none;
    padding-bottom: 0.5rem;
  }
  .search-box button{
    border: none;
    background: transparent;
  }
  
</style>
