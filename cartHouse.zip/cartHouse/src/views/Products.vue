<template>
  <div clas="main">
    <div id="app">
      <results-list v-if="results.items && results.items.length && !loading" :data="results.items"></results-list>
      <div class="center-text" v-else-if="loading">loading...</div>
      <div class="center-text" v-else>{{ errorText || `No Data Available!!` }}</div>
    </div>
    <pagination v-if="results.searchInformation && results.searchInformation.totalResults > 0" :pages="results.searchInformation && results.searchInformation.totalResults ? Math.floor(results.searchInformation.totalResults/10) +1  : 0" @pageSwitch="getNextResults"></pagination>
  </div>
</template>

<script>
// import axios from "axios"
import _ from "lodash"
import ResultsList from '@/components/ResultsList.vue'
import Pagination from '@/components/Pagination.vue'

export default {
  name: 'App',
  components: {
    ResultsList,
    Pagination
  },
  data(){
    return {
      results: {},
      loading: false,
      errorText: null
    }
  },
  computed: {
    // key(){
    //   return "AIzaSyDeq72CZovX3DnDbYXo1qNxT7i2m2MFiWw"
    // },
    // engineId() {
    //   return "73513ada48a4e8411"
    // }
  },
  mounted(){
    this.getProducts();
  },
  methods:{
    getProducts(){
      this.$store
        .dispatch("crud/get", {
          component: "product-list",
          filters: { }
        })
        .then(response => {
          if (response.status) {
            this.chartData = {
              ...this.chartData,
              items: [...response.data.nodes, ...response.data.links]
            };
          }
          this.loading = false;
        });
    },
    renderList(list){
      this.results = list;
    },
    searchDebounce: _.debounce(function(query){
      this.search(query);
    }, 300),
    search(){
      // this.loading = true;
      // this.query = query;
      // axios.get("https://dummyproducts-api.herokuapp.com/api/v1/products?apikey=5oIDTjlULgO8").then(response => { 
      //   this.results = response.data;
      //   this.loading = false;
      //   this.errorText = null;
      // })
      // .catch(() => {
      //   this.loading= false;
      //   this.errorText="Some went wrong, please try again later!"
      // })
    },
    // getNextResults(pageNo){
    //   this.search(this.query, pageNo);
    // }
  }
}
</script>

<style>
.center-text{
  text-align:center;
  margin-top:10rem;
}
</style>
