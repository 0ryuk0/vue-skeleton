<template>
  <div>
    Product Details
  </div>
</template>

<script>

export default {
  name: 'product-details',
}
</script>

