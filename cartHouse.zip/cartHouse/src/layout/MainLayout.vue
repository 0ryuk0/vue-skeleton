<template>
  <div clas="main">
      <app-header @search="searchDebounce"></app-header>
      <div class="main-layout-container">
        <router-view />
      </div>
  </div>
</template>

<script>
import axios from "axios"
import _ from "lodash"
import AppHeader from '@/components/AppHeader.vue'

export default {
  name: 'main-layout',
  components: {
    AppHeader
  },
  data(){
    return {
      results: {},
      loading: false,
      errorText: null
    }
  },
  computed: {
    key(){
      return "AIzaSyDeq72CZovX3DnDbYXo1qNxT7i2m2MFiWw"
    },
    engineId() {
      return "73513ada48a4e8411"
    }
  },
  methods:{
    renderList(list){
      this.results = list;
    },
    searchDebounce: _.debounce(function(query){
      this.search(query);
    }, 300),
    search(query, page=0){
      this.loading = true;
      this.query = query;
      axios.get(`https://www.googleapis.com/customsearch/v1?key=${this.key}&cx=${this.engineId}&q=${query}&start=${page*10+1}`).then(response => { 
        this.results = response.data;
        this.loading = false;
        this.errorText = null;
      })
      .catch(() => {
        this.loading= false;
        this.errorText="Some went wrong, please try again later!"
      })
    },
    getNextResults(pageNo){
      this.search(this.query, pageNo);
    }
  }
}
</script>

