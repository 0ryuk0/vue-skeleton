import Vue from "vue";
import Vuex from "vuex";
import crud from "./store/crud";
import config from "./store/config";
import auth from "./store/auth";

Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    requests: {},
  },
  getters: {
    getRedirectPath() {
      return localStorage.getItem("redirectPath");
    }
  },
  mutations: {
  },
  actions: {},
  modules: {
    crud,
    config,
    auth
  }
});
